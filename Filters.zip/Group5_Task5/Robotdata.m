d=robot_data(100); %extracting sensor data
u = 0.2; %robot velocity
dt = 1; %time sample
xs(1)=0; %initial position
x(1)=0; % initial position for estimate calculation
t(1)=0; % initial time
%calculating robot positon using Newton's equation
for i = 2:100
    xs(i) = u*dt+ xs(i-1);
    t(i) = dt + t(i-1);
end

sf=0.1; %scaling factor

%designing filter
for j =1:100
    res(j)= d(j)-x(j);
    x_est(j) = x(j) + sf*res(j); 
    x(j+1) = u*dt+ x_est(j);
end

%plotting 
hold on
plot(t,d,'g')
plot(t,xs,'r')
plot(t,x_est,'b')
legend({'Position: Sensor data','Position: Newton''s eqn','Filtered position'}, 'Location',"best")
xlabel('time (seconds)')
ylabel('position')
